./objects/irq_timer.o: ..\ex1\Source\timer\IRQ_timer.c \
  C:\Users\stefa\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\stefa\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  ..\ex1\Source\timer\timer.h ..\ex1\Source\timer\..\led\led.h
