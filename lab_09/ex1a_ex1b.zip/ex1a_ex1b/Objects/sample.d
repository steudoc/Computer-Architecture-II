./objects/sample.o: Source\sample.c \
  C:\Users\stefa\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\LPC17xx.H \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\stefa\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\system_LPC17xx.h \
  Source\led\led.h Source\button_EXINT\button.h
