.\objects\lfsr_step.o: lfsr_step.s
