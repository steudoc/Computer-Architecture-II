.\objects\fast_inv_sqrt.o: fast_inv_sqrt.s
