# 1 "Source/main.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 405 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "Source/main.c" 2


int main(void){

 unsigned int result;

 __asm volatile("SVC #0x0A\n");

 while(1);
}
